﻿# AMO Submission Notes for S_Detector


---

## Extension name
S_Detector

## Summary (short, ~250 chars max)
Real-time phishing and deceptive-site detector. Checks every site you visit against Google Safe Browsing, PhishTank, and OpenPhish, plus local heuristics for lookalike domains — with a clear warning screen, not a silent block.

## Full description

S_Detector protects you from phishing and deceptive websites in real time, using four layers of detection:

- **Google Safe Browsing** — live lookup against Google's continuously updated threat database.
- **PhishTank** — community-verified phishing URL feed, refreshed automatically.
- **OpenPhish** — a second independent phishing feed for redundancy.
- **Local heuristics** — catches brand-new phishing sites not yet in any database, by detecting punycode/homoglyph domains, brand lookalikes, insecure (non-HTTPS) connections, and other suspicious URL patterns — entirely on-device, no data sent anywhere for this layer.

When a site is flagged, S_Detector shows a clear warning screen explaining why — never a silent block — so you stay in control and can proceed if you're confident it's a false positive. Sites you choose to trust are remembered so you won't be warned again.

Open source. No ads, no tracking, no data sold. See the privacy policy for exactly what data is checked and where it goes.

## Category
Privacy & Security

## Tags
phishing, security, privacy, safe-browsing, anti-phishing

## Support / homepage URL
https://github.com/sithu-afk/S-Detector


## License
MIT

---



## Data collection permissions (required manifest field, since Nov 2025)

`manifest.json` declares:
```json
"data_collection_permissions": {
  "required": ["browsingActivity"]
}
```
This is required because S_Detector sends the URL of the page you're navigating to, to Google's Safe Browsing API, for its live phishing check. This is core to the extension's function and cannot be made optional. Firefox will show this to users as a consent prompt on install (requires Firefox 140+, hence `strict_min_version: "140.0"`).

## Reviewer notes 

This extension requests broad host permissions (`<all_urls>`) and `webNavigation` because its core function is to inspect the destination URL of every top-level page navigation before the page loads, to check it against phishing databases (Google Safe Browsing live API, cached PhishTank/OpenPhish feeds) and local heuristics. It does not read or transmit page content — only the URL string of the page being navigated to.

The only data sent to a third party is the destination URL, sent to Google's Safe Browsing API (`https://safebrowsing.googleapis.com`) for a real-time reputation check. PhishTank and OpenPhish checks are performed locally against periodically-downloaded feeds (`https://data.phishtank.com` and `https://openphish.com`) — no user data is sent to these services.

`alarms` permission is used solely to schedule periodic (hourly, configurable) refreshes of the PhishTank/OpenPhish feed cache. `storage` is used to cache feed data locally and remember user-approved allowlist entries. `notifications` permission is present for potential future use (e.g. background threat alerts) — [remove this line if you strip the unused permission before submission, see checklist below].

No remote code execution — all JavaScript is bundled in the extension package; no eval, no dynamically fetched/executed scripts.

---
### Packaging for upload
```
cd S_Detector
web-ext build --overwrite-dest
```
This produces a `.zip` in `web-ext-artifacts/` ready to upload at https://addons.mozilla.org/developers/addon/submit/

---


Right now, `SAFE_BROWSING_API_KEY` is meant to live in a git-ignored `background/config.js` on your machine. That's fine for personal use and testing, but if you ship this to AMO as a public extension, **every user would need their own API key** unless you change the architecture — since the key would otherwise be visible to anyone who unpacks the .xpi (browser extensions can't truly hide secrets client-side).

Two realistic paths for public release:
1. **Ship without Safe Browsing**, and rely on PhishTank + OpenPhish + heuristics only (all key-free) — simplest, no secret-management problem.
2. **Proxy Safe Browsing through your own small backend** (e.g. a free-tier Cloudflare Worker) that holds the real key server-side, and have the extension call your worker instead of Google directly — more setup, but keeps Safe Browsing in the mix for all users without exposing your key.

Worth deciding before you submit — happy to help scaffold either path.

