// warningInterstitial.js
// -----------------------------------------------------------------------
// Injected into every page. Listens for a warning message from the
// background script and, if received, overlays a full-page interstitial
// (similar to Firefox's built-in "Deceptive Site Ahead") instead of
// silently blocking the page — the user stays in control.
//
// SECURITY NOTE: this file deliberately avoids innerHTML entirely for any
// dynamic content (hostname, threat reasons). Everything user/feed/API
// derived is inserted via textContent or createElement, never parsed as
// HTML, so there is no XSS surface even if a future source starts
// returning attacker-influenced strings (e.g. a compromised feed).
// -----------------------------------------------------------------------

(() => {
  const OVERLAY_ID = "s-detector-warning-overlay";
  const EXTENSION_ID = browser.runtime.id;

  function buildOverlay(details) {
    if (document.getElementById(OVERLAY_ID)) return; // already shown

    const hostname = (() => {
      try { return new URL(details.url).hostname; } catch (e) { return String(details.url || "this site"); }
    })();

    const overlay = document.createElement("div");
    overlay.id = OVERLAY_ID;

    const box = document.createElement("div");
    box.className = "s-detector-box";

    const icon = document.createElement("div");
    icon.className = "s-detector-icon";
    icon.textContent = "\u26A0"; // warning triangle, plain text, no markup

    const heading = document.createElement("h1");
    heading.textContent = "Deceptive Site Warning";

    const sub = document.createElement("p");
    sub.className = "s-detector-sub";
    sub.append("S_Detector believes ");
    const strong = document.createElement("strong");
    strong.textContent = hostname; // textContent — never interpreted as HTML
    sub.append(strong);
    sub.append(" may be a phishing or deceptive site.");

    const reasonsUl = document.createElement("ul");
    reasonsUl.className = "s-detector-reasons";
    const allReasons = [...(details.sources || []), ...(details.reasons || [])];
    allReasons.forEach(reasonText => {
      const li = document.createElement("li");
      li.textContent = String(reasonText); // textContent — never interpreted as HTML
      reasonsUl.appendChild(li);
    });

    const actions = document.createElement("div");
    actions.className = "s-detector-actions";

    const backBtn = document.createElement("button");
    backBtn.id = "s-detector-back";
    backBtn.textContent = "Go Back (recommended)";
    backBtn.addEventListener("click", () => {
      history.back();
      overlay.remove();
    });

    const proceedBtn = document.createElement("button");
    proceedBtn.id = "s-detector-proceed";
    proceedBtn.textContent = "Proceed anyway";
    proceedBtn.addEventListener("click", async () => {
      await browser.runtime.sendMessage({
        type: "S_DETECTOR_ALLOW_SITE",
        hostname
      });
      overlay.remove();
    });

    actions.appendChild(backBtn);
    actions.appendChild(proceedBtn);

    const footer = document.createElement("p");
    footer.className = "s-detector-footer";
    footer.textContent = "Reported by S_Detector — a community phishing protection extension.";

    box.appendChild(icon);
    box.appendChild(heading);
    box.appendChild(sub);
    box.appendChild(reasonsUl);
    box.appendChild(actions);
    box.appendChild(footer);
    overlay.appendChild(box);

    document.documentElement.appendChild(overlay);
  }

  // Only accept messages that genuinely came from this extension's own
  // background script — not from web pages or other extensions. In MV3,
  // runtime.onMessage already only delivers messages from the extension's
  // own contexts by default (no externally_connectable is declared here),
  // but we check sender.id explicitly as defense in depth.
  browser.runtime.onMessage.addListener((message, sender) => {
    if (sender.id !== EXTENSION_ID) return;
    if (message.type === "S_DETECTOR_WARNING") {
      buildOverlay(message);
    }
  });

  // Fallback self-check: in case the background script's onBeforeNavigate
  // message arrives before this content script is ready, re-check on load.
  window.addEventListener("DOMContentLoaded", async () => {
    try {
      const result = await browser.runtime.sendMessage({
        type: "S_DETECTOR_CHECK_CURRENT",
        url: window.location.href
      });
      if (result && result.flagged) {
        buildOverlay({
          url: window.location.href,
          sources: result.sources,
          reasons: result.reasons
        });
      }
    } catch (e) {
      // Background script may be waking up; ignore.
    }
  });
})();
