document.addEventListener("DOMContentLoaded", async () => {
  try {
    const stats = await browser.runtime.sendMessage({ type: "S_DETECTOR_GET_STATS" });
    document.getElementById("stat-checked").textContent = stats?.checked ?? 0;
    document.getElementById("stat-flagged").textContent = stats?.flagged ?? 0;
  } catch (e) {
    // Background script may still be initializing.
  }
});
