const ALLOWLIST_KEY = "s_detector_allowlist";
const SETTINGS_KEY = "s_detector_source_settings";

async function loadSettings() {
  const stored = await browser.storage.local.get(SETTINGS_KEY);
  const settings = stored[SETTINGS_KEY] || {
    safeBrowsing: true,
    phishtank: true,
    openphish: true,
    heuristics: true
  };
  document.getElementById("toggle-safeBrowsing").checked = settings.safeBrowsing;
  document.getElementById("toggle-phishtank").checked = settings.phishtank;
  document.getElementById("toggle-openphish").checked = settings.openphish;
  document.getElementById("toggle-heuristics").checked = settings.heuristics;
}

function saveSettings() {
  const settings = {
    safeBrowsing: document.getElementById("toggle-safeBrowsing").checked,
    phishtank: document.getElementById("toggle-phishtank").checked,
    openphish: document.getElementById("toggle-openphish").checked,
    heuristics: document.getElementById("toggle-heuristics").checked
  };
  browser.storage.local.set({ [SETTINGS_KEY]: settings });
}

async function loadAllowlist() {
  const stored = await browser.storage.local.get(ALLOWLIST_KEY);
  const list = stored[ALLOWLIST_KEY] || [];
  const ul = document.getElementById("allowlist");
  ul.innerHTML = "";

  if (list.length === 0) {
    ul.innerHTML = "<li>No sites allowed yet.</li>";
    return;
  }

  list.forEach(hostname => {
    const li = document.createElement("li");
    const span = document.createElement("span");
    span.textContent = hostname;

    const removeBtn = document.createElement("button");
    removeBtn.textContent = "Remove";
    removeBtn.className = "remove";
    removeBtn.addEventListener("click", async () => {
      const updated = list.filter(h => h !== hostname);
      await browser.storage.local.set({ [ALLOWLIST_KEY]: updated });
      loadAllowlist();
    });

    li.appendChild(span);
    li.appendChild(removeBtn);
    ul.appendChild(li);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  loadSettings();
  loadAllowlist();

  ["toggle-safeBrowsing", "toggle-phishtank", "toggle-openphish", "toggle-heuristics"]
    .forEach(id => document.getElementById(id).addEventListener("change", saveSettings));
});
