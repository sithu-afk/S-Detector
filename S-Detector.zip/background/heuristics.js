// heuristics.js
// -----------------------------------------------------------------------
// Local, offline heuristics for flagging suspicious URLs that haven't
// been indexed by any external feed yet (e.g. brand-new phishing sites).
// These run instantly and never leave the browser.
// -----------------------------------------------------------------------

const S_DetectorHeuristics = (() => {

  // A small list of commonly-impersonated brands. Extend as needed.
  const COMMON_TARGETS = [
    "paypal", "microsoft", "apple", "google", "amazon", "facebook",
    "netflix", "bankofamerica", "wellsfargo", "chase", "instagram",
    "coinbase", "binance", "outlook", "office365", "icloud"
  ];

  // Very small Levenshtein distance implementation for lookalike checks.
  function levenshtein(a, b) {
    const matrix = Array.from({ length: a.length + 1 }, (_, i) =>
      [i, ...Array(b.length).fill(0)]
    );
    for (let j = 0; j <= b.length; j++) matrix[0][j] = j;

    for (let i = 1; i <= a.length; i++) {
      for (let j = 1; j <= b.length; j++) {
        const cost = a[i - 1] === b[j - 1] ? 0 : 1;
        matrix[i][j] = Math.min(
          matrix[i - 1][j] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j - 1] + cost
        );
      }
    }
    return matrix[a.length][b.length];
  }

  function isPunycode(hostname) {
    return hostname.split(".").some(label => label.startsWith("xn--"));
  }

  function hasSuspiciousChars(hostname) {
    // Mixed script detection is complex; this is a lightweight proxy:
    // flag hostnames containing non-ASCII characters outside punycode form.
    return /[^\x00-\x7F]/.test(hostname);
  }

  function lookalikeBrand(hostname) {
    const cleanHost = hostname
      .replace(/^www\./, "")
      .split(".")[0]
      .toLowerCase();

    for (const brand of COMMON_TARGETS) {
      if (cleanHost === brand) continue; // exact match = legitimate-looking, not lookalike
      const distance = levenshtein(cleanHost, brand);
      // Close but not exact, and not a totally unrelated short string.
      if (distance > 0 && distance <= 2 && cleanHost.length >= brand.length - 2) {
        return brand;
      }
    }
    return null;
  }

  function excessiveSubdomains(hostname) {
    return hostname.split(".").length > 4;
  }

  function isIpAddressHost(hostname) {
    return /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname);
  }

  /**
   * Runs all heuristic checks against a URL.
   * Returns { suspicious: boolean, reasons: string[] }
   */
  function evaluate(urlString) {
    const reasons = [];
    let url;
    try {
      url = new URL(urlString);
    } catch (e) {
      return { suspicious: false, reasons: [] };
    }

    const hostname = url.hostname;

    if (isPunycode(hostname)) {
      reasons.push("Punycode-encoded domain (possible homoglyph attack)");
    }
    if (hasSuspiciousChars(hostname)) {
      reasons.push("Hostname contains non-standard characters");
    }
    if (isIpAddressHost(hostname)) {
      reasons.push("Site is addressed directly by IP rather than domain name");
    }
    if (excessiveSubdomains(hostname)) {
      reasons.push("Unusually deep subdomain structure");
    }
    const lookalike = lookalikeBrand(hostname);
    if (lookalike) {
      reasons.push(`Domain closely resembles "${lookalike}" but is not an exact match`);
    }
    if (url.protocol !== "https:") {
      reasons.push("Connection is not encrypted (HTTP, not HTTPS)");
    }

    return { suspicious: reasons.length > 0, reasons };
  }

  return { evaluate };
})();
