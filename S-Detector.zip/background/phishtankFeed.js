// phishtankFeed.js
// -----------------------------------------------------------------------
// Downloads PhishTank's free public feed of verified phishing URLs
// (no API key required) and caches it in browser.storage.local for
// fast offline lookups between refreshes.
// -----------------------------------------------------------------------

const S_DetectorPhishTank = (() => {

  const STORAGE_KEY = "s_detector_phishtank_cache";

  async function refreshFeed() {
    try {
      const response = await fetch(S_DETECTOR_CONFIG.PHISHTANK_FEED_URL, {
        headers: {
          // PhishTank asks integrators to identify their application.
          "User-Agent": "S_Detector/0.1.0 (+https://github.com/sithu-afk/S_Detector)"
        }
      });

      if (!response.ok) {
        console.warn("S_Detector: PhishTank feed fetch failed", response.status);
        return;
      }

      const entries = await response.json();

      // SECURITY: validate the shape of feed data before trusting it.
      // Never assume an external response is well-formed — a compromised
      // or malfunctioning feed could return non-array data, oversized
      // payloads, or malformed entries.
      if (!Array.isArray(entries)) {
        console.warn("S_Detector: PhishTank feed returned unexpected shape, skipping");
        return;
      }

      const MAX_ENTRIES = 200000; // sane upper bound to avoid unbounded storage growth
      const MAX_URL_LENGTH = 2048;

      const urlSet = entries
        .filter(e => e && typeof e.url === "string" && e.url.length > 0 && e.url.length <= MAX_URL_LENGTH)
        .map(e => e.url.trim().toLowerCase())
        .slice(0, MAX_ENTRIES);

      await browser.storage.local.set({
        [STORAGE_KEY]: {
          urls: urlSet,
          updatedAt: Date.now()
        }
      });

      console.info(`S_Detector: PhishTank cache refreshed (${urlSet.length} entries)`);
    } catch (err) {
      console.warn("S_Detector: PhishTank feed refresh error", err);
    }
  }

  async function checkUrl(urlString) {
    const stored = await browser.storage.local.get(STORAGE_KEY);
    const cache = stored[STORAGE_KEY];
    if (!cache || !cache.urls) {
      return { flagged: false };
    }
    const normalized = urlString.trim().toLowerCase();
    return { flagged: cache.urls.includes(normalized) };
  }

  return { refreshFeed, checkUrl };
})();
