// openphishFeed.js
// -----------------------------------------------------------------------
// Downloads OpenPhish's free community feed (plain text, one URL per
// line, no API key required) as a secondary/redundant phishing source.
// -----------------------------------------------------------------------

const S_DetectorOpenPhish = (() => {

  const STORAGE_KEY = "s_detector_openphish_cache";

  async function refreshFeed() {
    try {
      const response = await fetch(S_DETECTOR_CONFIG.OPENPHISH_FEED_URL, {
        headers: {
          "User-Agent": "S_Detector/0.1.0 (+https://github.com/sithu-afk/S_Detector)"
        }
      });

      if (!response.ok) {
        console.warn("S_Detector: OpenPhish feed fetch failed", response.status);
        return;
      }

      const text = await response.text();

      // SECURITY: validate/bound feed data before trusting it — see note
      // in phishtankFeed.js for rationale.
      const MAX_ENTRIES = 200000;
      const MAX_URL_LENGTH = 2048;

      const urlSet = text
        .split("\n")
        .map(line => line.trim().toLowerCase())
        .filter(line => line.length > 0 && line.length <= MAX_URL_LENGTH)
        .slice(0, MAX_ENTRIES);

      await browser.storage.local.set({
        [STORAGE_KEY]: {
          urls: urlSet,
          updatedAt: Date.now()
        }
      });

      console.info(`S_Detector: OpenPhish cache refreshed (${urlSet.length} entries)`);
    } catch (err) {
      console.warn("S_Detector: OpenPhish feed refresh error", err);
    }
  }

  async function checkUrl(urlString) {
    const stored = await browser.storage.local.get(STORAGE_KEY);
    const cache = stored[STORAGE_KEY];
    if (!cache || !cache.urls) {
      return { flagged: false };
    }
    const normalized = urlString.trim().toLowerCase();
    return { flagged: cache.urls.includes(normalized) };
  }

  return { refreshFeed, checkUrl };
})();
