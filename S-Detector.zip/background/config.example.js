// config.js
// -----------------------------------------------------------------------
// S_Detector configuration
//
// Get a free Google Safe Browsing API key here:
//   https://developers.google.com/safe-browsing/v4/get-started
// (Enable the "Safe Browsing API" in Google Cloud Console, create an
//  API key, and paste it below. Do NOT commit your real key to a public
//  repo — load it from browser.storage or a local untracked file instead
//  for anything beyond local testing.)
// -----------------------------------------------------------------------

const S_DETECTOR_CONFIG = {
  SAFE_BROWSING_API_KEY: "PASTE_YOUR_GOOGLE_SAFE_BROWSING_API_KEY_HERE",

  // How often to refresh the PhishTank / OpenPhish bulk feeds, in minutes.
  FEED_REFRESH_INTERVAL_MINUTES: 60,

  // Feed URLs (no API key required for either of these).
  PHISHTANK_FEED_URL: "https://data.phishtank.com/data/online-valid.json",
  OPENPHISH_FEED_URL: "https://openphish.com/feed.txt",

  // Toggle individual detection sources on/off.
  SOURCES: {
    safeBrowsing: true,
    phishtank: true,
    openphish: true,
    heuristics: true
  }
};
