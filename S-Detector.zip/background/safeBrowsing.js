// safeBrowsing.js
// -----------------------------------------------------------------------
// Live lookups against the Google Safe Browsing v4 API.
// Requires a free API key — see config.js for setup instructions.
// -----------------------------------------------------------------------

const S_DetectorSafeBrowsing = (() => {

  const ENDPOINT = "https://safebrowsing.googleapis.com/v4/threatMatches:find";

  /**
   * Checks a single URL against Safe Browsing.
   * Returns { flagged: boolean, threatType: string|null }
   */
  async function checkUrl(urlString) {
    const apiKey = S_DETECTOR_CONFIG.SAFE_BROWSING_API_KEY;

    if (!apiKey || apiKey.startsWith("PASTE_YOUR")) {
      // No key configured yet — silently skip this source.
      return { flagged: false, threatType: null, skipped: true };
    }

    const body = {
      client: {
        clientId: "s_detector",
        clientVersion: "0.1.0"
      },
      threatInfo: {
        threatTypes: [
          "SOCIAL_ENGINEERING", // phishing
          "MALWARE",
          "UNWANTED_SOFTWARE"
        ],
        platformTypes: ["ANY_PLATFORM"],
        threatEntryTypes: ["URL"],
        threatEntries: [{ url: urlString }]
      }
    };

    try {
      const response = await fetch(`${ENDPOINT}?key=${apiKey}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        console.warn("S_Detector: Safe Browsing request failed", response.status);
        return { flagged: false, threatType: null, error: true };
      }

      const data = await response.json();

      // SECURITY: validate response shape before trusting it — don't
      // assume the API always returns exactly what's expected.
      if (data && Array.isArray(data.matches) && data.matches.length > 0) {
        const threatType = typeof data.matches[0]?.threatType === "string"
          ? data.matches[0].threatType
          : "UNKNOWN";
        return { flagged: true, threatType };
      }
      return { flagged: false, threatType: null };
    } catch (err) {
      console.warn("S_Detector: Safe Browsing request error", err);
      return { flagged: false, threatType: null, error: true };
    }
  }

  return { checkUrl };
})();
