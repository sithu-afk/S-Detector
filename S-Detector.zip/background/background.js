// background.js
// -----------------------------------------------------------------------
// S_Detector main controller.
//   - Schedules periodic PhishTank / OpenPhish feed refreshes
//   - Intercepts navigation and checks the destination URL against all
//     enabled sources (cache lookups first, then live Safe Browsing call)
//   - Tells the content script to show a warning interstitial if flagged
//   - Maintains a small allowlist so users can dismiss false positives
// -----------------------------------------------------------------------

const ALARM_NAME = "s_detector_feed_refresh";
const ALLOWLIST_KEY = "s_detector_allowlist";
const STATS_KEY = "s_detector_stats";

// ---- Feed scheduling -----------------------------------------------------

async function refreshAllFeeds() {
  if (S_DETECTOR_CONFIG.SOURCES.phishtank) {
    await S_DetectorPhishTank.refreshFeed();
  }
  if (S_DETECTOR_CONFIG.SOURCES.openphish) {
    await S_DetectorOpenPhish.refreshFeed();
  }
}

browser.runtime.onInstalled.addListener(async () => {
  await refreshAllFeeds();
  browser.alarms.create(ALARM_NAME, {
    periodInMinutes: S_DETECTOR_CONFIG.FEED_REFRESH_INTERVAL_MINUTES
  });
});

browser.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === ALARM_NAME) {
    refreshAllFeeds();
  }
});

// ---- Allowlist helpers -----------------------------------------------------

async function isAllowlisted(hostname) {
  const stored = await browser.storage.local.get(ALLOWLIST_KEY);
  const list = stored[ALLOWLIST_KEY] || [];
  return list.includes(hostname);
}

async function addToAllowlist(hostname) {
  const stored = await browser.storage.local.get(ALLOWLIST_KEY);
  const list = stored[ALLOWLIST_KEY] || [];
  if (!list.includes(hostname)) {
    list.push(hostname);
    await browser.storage.local.set({ [ALLOWLIST_KEY]: list });
  }
}

// ---- Stats (shown in popup) -----------------------------------------------------

async function incrementStat(key) {
  const stored = await browser.storage.local.get(STATS_KEY);
  const stats = stored[STATS_KEY] || { checked: 0, flagged: 0 };
  stats[key] = (stats[key] || 0) + 1;
  await browser.storage.local.set({ [STATS_KEY]: stats });
}

// ---- Core evaluation -----------------------------------------------------

/**
 * Runs a URL through every enabled source.
 * Returns { flagged: boolean, sources: string[], reasons: string[] }
 */
async function evaluateUrl(urlString) {
  const flaggedBy = [];
  const reasons = [];

  // 1. Cached feeds first — fastest, no network round trip.
  if (S_DETECTOR_CONFIG.SOURCES.phishtank) {
    const result = await S_DetectorPhishTank.checkUrl(urlString);
    if (result.flagged) flaggedBy.push("PhishTank");
  }
  if (S_DETECTOR_CONFIG.SOURCES.openphish) {
    const result = await S_DetectorOpenPhish.checkUrl(urlString);
    if (result.flagged) flaggedBy.push("OpenPhish");
  }

  // 2. Live Safe Browsing lookup.
  if (S_DETECTOR_CONFIG.SOURCES.safeBrowsing) {
    const result = await S_DetectorSafeBrowsing.checkUrl(urlString);
    if (result.flagged) flaggedBy.push(`Google Safe Browsing (${result.threatType})`);
  }

  // 3. Local heuristics — always cheap, run last so feed hits short-circuit nothing.
  if (S_DETECTOR_CONFIG.SOURCES.heuristics) {
    const result = S_DetectorHeuristics.evaluate(urlString);
    if (result.suspicious) {
      reasons.push(...result.reasons);
    }
  }

  const flagged = flaggedBy.length > 0 || reasons.length >= 2; // require 2+ heuristic hits alone
  return { flagged, sources: flaggedBy, reasons };
}

// ---- Navigation interception -----------------------------------------------------

browser.webNavigation.onBeforeNavigate.addListener(async details => {
  // Only check top-level frame navigations (not iframes/ads/etc).
  if (details.frameId !== 0) return;

  let hostname;
  try {
    hostname = new URL(details.url).hostname;
  } catch (e) {
    return;
  }

  // Skip internal/browser pages.
  if (!/^https?:$/.test(new URL(details.url).protocol)) return;

  if (await isAllowlisted(hostname)) return;

  await incrementStat("checked");

  const result = await evaluateUrl(details.url);

  if (result.flagged) {
    await incrementStat("flagged");
    try {
      await browser.tabs.sendMessage(details.tabId, {
        type: "S_DETECTOR_WARNING",
        url: details.url,
        sources: result.sources,
        reasons: result.reasons
      });
    } catch (e) {
      // Content script may not be injected yet on very first navigation;
      // the content script also self-checks on load as a fallback.
    }
  }
}, { url: [{ schemes: ["http", "https"] }] });

// ---- Messages from content script / popup -----------------------------------------------------

browser.runtime.onMessage.addListener(async (message, sender) => {
  // Defense in depth: only handle messages that originated from this
  // extension's own content scripts / popup / options page — not from
  // web pages or other extensions. externally_connectable is not declared
  // in manifest.json, so onMessage already restricts this by default, but
  // we check explicitly rather than relying solely on that default.
  if (sender.id !== browser.runtime.id) return;

  if (message.type === "S_DETECTOR_CHECK_CURRENT") {
    return evaluateUrl(message.url);
  }
  if (message.type === "S_DETECTOR_ALLOW_SITE") {
    await addToAllowlist(message.hostname);
    return { ok: true };
  }
  if (message.type === "S_DETECTOR_GET_STATS") {
    const stored = await browser.storage.local.get(STATS_KEY);
    return stored[STATS_KEY] || { checked: 0, flagged: 0 };
  }
});
